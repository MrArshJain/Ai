import { useState, useRef } from 'react';
import { FileVideo, Loader2, Upload, Send } from 'lucide-react';
import { ai } from '../services/gemini';
import Markdown from 'react-markdown';

export default function VideoAnalyze() {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sourceVideo, setSourceVideo] = useState<string | null>(null);
  const [sourceMimeType, setSourceMimeType] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      setSourceVideo(result);
      setSourceMimeType(file.type);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || !sourceVideo || isLoading) return;

    setIsLoading(true);
    setAnalysisResult(null);

    try {
      const base64Data = sourceVideo.split(',')[1];
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: sourceMimeType,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      });

      setAnalysisResult(response.text || 'No analysis provided.');
    } catch (error) {
      console.error('Error analyzing video:', error);
      alert('Failed to analyze video. Please check console for details. Note: Video size must be small enough for inlineData.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900 overflow-y-auto">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50">
        <h2 className="text-xl font-semibold text-white flex items-center gap-2">
          <FileVideo className="w-6 h-6 text-orange-500" />
          Video Analysis
        </h2>
        <p className="text-sm text-zinc-400">Powered by gemini-3.1-pro-preview</p>
      </div>

      <div className="p-6 max-w-4xl mx-auto w-full space-y-8">
        <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800">
          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Upload Video (Small size only)</label>
            <div 
              className="border-2 border-dashed border-zinc-700 rounded-xl p-8 text-center cursor-pointer hover:bg-zinc-900/50 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                accept="video/*" 
                className="hidden" 
              />
              {sourceVideo ? (
                <div className="flex flex-col items-center gap-4">
                  <video src={sourceVideo} controls className="max-h-48 rounded-lg object-contain" />
                  <span className="text-sm text-zinc-400">Click to change video</span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-4 text-zinc-400">
                  <Upload className="w-8 h-8" />
                  <span>Click to upload a video</span>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Analysis Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="What do you want to know about this video?"
              className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent min-h-[100px] resize-y"
              disabled={isLoading}
            />
          </div>

          <button
            type="submit"
            disabled={!prompt.trim() || !sourceVideo || isLoading}
            className="w-full bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-medium py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                Analyze Video
              </>
            )}
          </button>
        </form>

        {analysisResult && (
          <div className="bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800 space-y-4">
            <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Analysis Result</h3>
            <div className="prose prose-invert max-w-none">
              <Markdown>{analysisResult}</Markdown>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
