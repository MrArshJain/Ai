import { useState, useRef, useEffect } from 'react';
import { Video, Loader2, Upload, Download } from 'lucide-react';
import { ai } from '../services/gemini';

export default function VideoGen() {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [isLoading, setIsLoading] = useState(false);
  const [sourceImage, setSourceImage] = useState<string | null>(null);
  const [sourceMimeType, setSourceMimeType] = useState<string>('');
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [loadingMessage, setLoadingMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      setSourceImage(result);
      setSourceMimeType(file.type);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || !sourceImage || isLoading) return;

    setIsLoading(true);
    setGeneratedVideoUrl(null);
    setLoadingMessage('Starting video generation...');

    try {
      const base64Data = sourceImage.split(',')[1];
      
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        image: {
          imageBytes: base64Data,
          mimeType: sourceMimeType,
        },
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio,
        }
      });

      setLoadingMessage('Generating video... This may take a few minutes.');

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        setLoadingMessage('Still generating... Please wait.');
        operation = await ai.operations.getVideosOperation({operation: operation});
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      
      if (downloadLink) {
        setLoadingMessage('Fetching video...');
        const response = await fetch(downloadLink, {
          method: 'GET',
          headers: {
            'x-goog-api-key': process.env.GEMINI_API_KEY || '',
          },
        });
        
        if (response.ok) {
          const blob = await response.blob();
          const objectUrl = URL.createObjectURL(blob);
          setGeneratedVideoUrl(objectUrl);
        } else {
          throw new Error('Failed to fetch video from URI');
        }
      } else {
        throw new Error('No video URI returned');
      }

    } catch (error) {
      console.error('Error generating video:', error);
      alert('Failed to generate video. Please check console for details.');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  // Cleanup object URL
  useEffect(() => {
    return () => {
      if (generatedVideoUrl) {
        URL.revokeObjectURL(generatedVideoUrl);
      }
    };
  }, [generatedVideoUrl]);

  return (
    <div className="flex flex-col h-full bg-zinc-900 overflow-y-auto">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50">
        <h2 className="text-xl font-semibold text-white flex items-center gap-2">
          <Video className="w-6 h-6 text-red-500" />
          Video Generation
        </h2>
        <p className="text-sm text-zinc-400">Powered by veo-3.1-fast-generate-preview</p>
      </div>

      <div className="p-6 max-w-4xl mx-auto w-full space-y-8">
        <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800">
          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Starting Image</label>
            <div 
              className="border-2 border-dashed border-zinc-700 rounded-xl p-8 text-center cursor-pointer hover:bg-zinc-900/50 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                accept="image/*" 
                className="hidden" 
              />
              {sourceImage ? (
                <div className="flex flex-col items-center gap-4">
                  <img src={sourceImage} alt="Source" className="max-h-48 rounded-lg object-contain" />
                  <span className="text-sm text-zinc-400">Click to change image</span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-4 text-zinc-400">
                  <Upload className="w-8 h-8" />
                  <span>Click to upload a starting image</span>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Animation Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe how the image should animate..."
              className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent min-h-[100px] resize-y"
              disabled={isLoading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Aspect Ratio</label>
            <select
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value as '16:9' | '9:16')}
              className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-red-500"
              disabled={isLoading}
            >
              <option value="16:9">16:9 (Landscape)</option>
              <option value="9:16">9:16 (Portrait)</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={!prompt.trim() || !sourceImage || isLoading}
            className="w-full bg-red-500 hover:bg-red-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-medium py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                {loadingMessage}
              </>
            ) : (
              <>
                <Video className="w-5 h-5" />
                Generate Video
              </>
            )}
          </button>
        </form>

        {generatedVideoUrl && (
          <div className="bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium text-white">Result</h3>
              <a
                href={generatedVideoUrl}
                download="generated-video.mp4"
                className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300"
              >
                <Download className="w-4 h-4" />
                Download
              </a>
            </div>
            <div className="rounded-xl overflow-hidden border border-zinc-800 bg-zinc-900 flex items-center justify-center min-h-[300px]">
              <video src={generatedVideoUrl} controls className="max-w-full max-h-[600px] object-contain" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
