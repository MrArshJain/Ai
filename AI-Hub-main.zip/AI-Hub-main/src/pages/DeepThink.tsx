import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Brain, Play, Code2, Terminal } from 'lucide-react';
import { ai } from '../services/gemini';
import { ThinkingLevel } from '@google/genai';
import Markdown from 'react-markdown';
import Editor from '@monaco-editor/react';

interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
}

export default function DeepThink() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [code, setCode] = useState('// Write your JavaScript code here\nconsole.log("Hello, World!");\n');
  const [output, setOutput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: userMessage,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
          systemInstruction: "You are an expert software engineer and computer scientist. Help the user write, debug, and understand code. Provide clear, concise, and optimal code snippets. You can also solve complex logic and math problems.",
        }
      });

      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'model', content: response.text || 'No response' }
      ]);
    } catch (error) {
      console.error('Error generating content:', error);
      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'model', content: 'Sorry, I encountered an error.' }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const runCode = () => {
    let logs: string[] = [];
    const originalConsoleLog = console.log;
    const originalConsoleError = console.error;
    
    console.log = (...args) => {
      logs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' '));
      originalConsoleLog(...args);
    };
    console.error = (...args) => {
      logs.push('ERROR: ' + args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' '));
      originalConsoleError(...args);
    };

    try {
      // eslint-disable-next-line no-new-func
      const result = new Function(code)();
      if (result !== undefined) {
        logs.push(String(result));
      }
      setOutput(logs.join('\n') || 'Code executed successfully with no output.');
    } catch (err: any) {
      setOutput(err.toString());
    } finally {
      console.log = originalConsoleLog;
      console.error = originalConsoleError;
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-500" />
            Deep Think & Code
          </h2>
          <p className="text-sm text-zinc-400">Powered by gemini-3.1-pro-preview (ThinkingLevel.HIGH)</p>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
        {/* Chat Section */}
        <div className="flex-1 flex flex-col border-r border-zinc-800 md:w-1/2">
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-zinc-500 space-y-4">
                <Brain className="w-16 h-16 opacity-20 text-purple-500" />
                <p>Ask complex coding questions requiring deep reasoning</p>
              </div>
            )}
            
            {messages.map((msg) => (
              <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  msg.role === 'user' ? 'bg-purple-500' : 'bg-zinc-800'
                }`}>
                  {msg.role === 'user' ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-purple-500" />}
                </div>
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  msg.role === 'user' 
                    ? 'bg-purple-500 text-white' 
                    : 'bg-zinc-800 text-zinc-200'
                }`}>
                  {msg.role === 'user' ? (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  ) : (
                    <div className="markdown-body prose prose-invert max-w-none">
                      <Markdown>{msg.content}</Markdown>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center shrink-0">
                  <Bot className="w-5 h-5 text-purple-500" />
                </div>
                <div className="bg-zinc-800 rounded-2xl px-4 py-3 flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin text-zinc-400" />
                  <span className="text-zinc-400">Thinking deeply...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 bg-zinc-950/50 border-t border-zinc-800">
            <form onSubmit={handleSubmit} className="relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask a complex coding question..."
                className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-full pl-6 pr-14 py-4 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="absolute right-2 top-2 bottom-2 aspect-square flex items-center justify-center bg-purple-500 hover:bg-purple-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white rounded-full transition-colors"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>

        {/* Code Editor Section */}
        <div className="flex-1 flex flex-col md:w-1/2 bg-[#1e1e1e]">
          <div className="flex items-center justify-between p-2 border-b border-zinc-800 bg-zinc-900">
            <div className="flex items-center gap-2 text-zinc-400 px-2">
              <Code2 className="w-4 h-4" />
              <span className="text-sm font-medium">JavaScript Editor</span>
            </div>
            <button
              onClick={runCode}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-1.5 rounded-md text-sm font-medium transition-colors"
            >
              <Play className="w-4 h-4" />
              Run Code
            </button>
          </div>
          
          <div className="flex-1 min-h-[300px]">
            <Editor
              height="100%"
              defaultLanguage="javascript"
              theme="vs-dark"
              value={code}
              onChange={(value) => setCode(value || '')}
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                wordWrap: 'on',
                padding: { top: 16 },
              }}
            />
          </div>

          {/* Output Console */}
          <div className="h-1/3 border-t border-zinc-800 bg-zinc-950 flex flex-col">
            <div className="flex items-center gap-2 text-zinc-400 p-2 border-b border-zinc-800 bg-zinc-900">
              <Terminal className="w-4 h-4" />
              <span className="text-sm font-medium">Console Output</span>
            </div>
            <div className="flex-1 p-4 overflow-y-auto font-mono text-sm text-zinc-300 whitespace-pre-wrap">
              {output || <span className="text-zinc-600 italic">No output yet. Run some code!</span>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
