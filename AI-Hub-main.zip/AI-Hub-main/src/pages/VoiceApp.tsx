import { useState, useRef, useEffect } from 'react';
import { Mic, Square, Loader2, Volume2 } from 'lucide-react';
import { ai } from '../services/gemini';
import { Modality, LiveServerMessage } from '@google/genai';

export default function VoiceApp() {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string[]>([]);
  
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const playbackQueueRef = useRef<Float32Array[]>([]);
  const isPlayingRef = useRef(false);

  const connect = async () => {
    setIsConnecting(true);
    setError(null);
    setTranscript([]);

    try {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      // Input audio needs to be 16kHz PCM
      const inputContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const source = inputContext.createMediaStreamSource(stream);
      
      // Use ScriptProcessorNode for simplicity in this demo (AudioWorklet is better for production)
      const processor = inputContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
             setIsConnected(true);
             setIsConnecting(false);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle audio output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              playAudio(base64Audio);
            }
            
            // Handle interruption
            if (message.serverContent?.interrupted) {
              playbackQueueRef.current = [];
              isPlayingRef.current = false;
            }
          },
          onerror: (err) => {
            console.error('Live API Error:', err);
            setError('Connection error occurred.');
            disconnect();
          },
          onclose: () => {
            disconnect();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
          },
          systemInstruction: "You are a helpful voice assistant. Keep your answers concise and conversational.",
        },
      });

      processor.onaudioprocess = (e) => {
        if (!isConnected) return;
        const inputData = e.inputBuffer.getChannelData(0);
        // Convert Float32 to Int16
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-32768, Math.min(32767, inputData[i] * 32768));
        }
        
        // Convert to base64
        const buffer = new Uint8Array(pcmData.buffer);
        let binary = '';
        for (let i = 0; i < buffer.byteLength; i++) {
          binary += String.fromCharCode(buffer[i]);
        }
        const base64Data = btoa(binary);

        sessionPromise.then((session) => {
          session.sendRealtimeInput({
            media: {
              mimeType: 'audio/pcm;rate=16000',
              data: base64Data
            }
          });
        }).catch(console.error);
      };

      source.connect(processor);
      processor.connect(inputContext.destination);

      const session = await sessionPromise;
      sessionRef.current = session;

    } catch (err) {
      console.error('Failed to connect:', err);
      setError('Failed to start voice session. Please check microphone permissions.');
      setIsConnecting(false);
      disconnect();
    }
  };

  const playAudio = async (base64Data: string) => {
    if (!audioContextRef.current) return;
    
    // Decode base64 to binary
    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    // The audio is 24kHz PCM Int16
    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }

    playbackQueueRef.current.push(float32Array);
    
    if (!isPlayingRef.current) {
      processPlaybackQueue();
    }
  };

  const processPlaybackQueue = () => {
    if (playbackQueueRef.current.length === 0 || !audioContextRef.current) {
      isPlayingRef.current = false;
      return;
    }

    isPlayingRef.current = true;
    const audioData = playbackQueueRef.current.shift()!;
    
    const audioBuffer = audioContextRef.current.createBuffer(1, audioData.length, 24000);
    audioBuffer.getChannelData(0).set(audioData);
    
    const source = audioContextRef.current.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContextRef.current.destination);
    
    source.onended = () => {
      processPlaybackQueue();
    };
    
    source.start();
  };

  const disconnect = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setIsConnected(false);
    setIsConnecting(false);
    playbackQueueRef.current = [];
    isPlayingRef.current = false;
  };

  useEffect(() => {
    return () => {
      disconnect();
    };
  }, []);

  return (
    <div className="flex flex-col h-full bg-zinc-900 overflow-y-auto">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50">
        <h2 className="text-xl font-semibold text-white flex items-center gap-2">
          <Volume2 className="w-6 h-6 text-teal-500" />
          Conversational Voice App
        </h2>
        <p className="text-sm text-zinc-400">Powered by gemini-2.5-flash-native-audio-preview-09-2025</p>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-8">
        <div className={`w-48 h-48 rounded-full flex items-center justify-center transition-all duration-500 ${
          isConnected ? 'bg-teal-500/20 shadow-[0_0_50px_rgba(20,184,166,0.3)]' : 'bg-zinc-800'
        }`}>
          {isConnected ? (
            <div className="relative flex items-center justify-center">
              <div className="absolute w-32 h-32 bg-teal-500/30 rounded-full animate-ping" />
              <Volume2 className="w-16 h-16 text-teal-500 relative z-10" />
            </div>
          ) : (
            <Mic className="w-16 h-16 text-zinc-500" />
          )}
        </div>

        <div className="text-center space-y-2">
          <h3 className="text-2xl font-semibold text-white">
            {isConnecting ? 'Connecting...' : isConnected ? 'Listening...' : 'Ready to talk?'}
          </h3>
          <p className="text-zinc-400 max-w-md mx-auto">
            {isConnected 
              ? 'Speak into your microphone. Gemini will respond with voice.' 
              : 'Click the button below to start a real-time voice conversation with Gemini.'}
          </p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-500 px-4 py-3 rounded-xl max-w-md text-center">
            {error}
          </div>
        )}

        <button
          onClick={isConnected ? disconnect : connect}
          disabled={isConnecting}
          className={`
            flex items-center gap-2 px-8 py-4 rounded-full font-medium text-lg transition-all
            ${isConnected 
              ? 'bg-red-500 hover:bg-red-600 text-white' 
              : 'bg-teal-500 hover:bg-teal-600 text-white'
            }
            disabled:opacity-50 disabled:cursor-not-allowed
          `}
        >
          {isConnecting ? (
            <>
              <Loader2 className="w-6 h-6 animate-spin" />
              Connecting...
            </>
          ) : isConnected ? (
            <>
              <Square className="w-6 h-6 fill-current" />
              End Conversation
            </>
          ) : (
            <>
              <Mic className="w-6 h-6" />
              Start Conversation
            </>
          )}
        </button>
      </div>
    </div>
  );
}
