import { useState, useRef } from 'react';
import { Mic, Loader2, Upload, Send, Square } from 'lucide-react';
import { ai } from '../services/gemini';
import Markdown from 'react-markdown';

export default function AudioTranscribe() {
  const [prompt, setPrompt] = useState('Transcribe this audio.');
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [sourceAudio, setSourceAudio] = useState<string | null>(null);
  const [sourceMimeType, setSourceMimeType] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      setSourceAudio(result);
      setSourceMimeType(file.type);
    };
    reader.readAsDataURL(file);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          setSourceAudio(reader.result as string);
          setSourceMimeType('audio/webm');
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Could not access microphone.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || !sourceAudio || isLoading) return;

    setIsLoading(true);
    setAnalysisResult(null);

    try {
      const base64Data = sourceAudio.split(',')[1];
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: sourceMimeType,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      });

      setAnalysisResult(response.text || 'No transcription provided.');
    } catch (error) {
      console.error('Error transcribing audio:', error);
      alert('Failed to transcribe audio. Please check console for details.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900 overflow-y-auto">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50">
        <h2 className="text-xl font-semibold text-white flex items-center gap-2">
          <Mic className="w-6 h-6 text-cyan-500" />
          Audio Transcription
        </h2>
        <p className="text-sm text-zinc-400">Powered by gemini-3-flash-preview</p>
      </div>

      <div className="p-6 max-w-4xl mx-auto w-full space-y-8">
        <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800">
          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Audio Source</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div 
                className="border-2 border-dashed border-zinc-700 rounded-xl p-8 text-center cursor-pointer hover:bg-zinc-900/50 transition-colors flex flex-col items-center justify-center min-h-[160px]"
                onClick={() => fileInputRef.current?.click()}
              >
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  accept="audio/*" 
                  className="hidden" 
                />
                <Upload className="w-8 h-8 text-zinc-400 mb-2" />
                <span className="text-zinc-400">Upload Audio File</span>
              </div>
              
              <div className="border-2 border-dashed border-zinc-700 rounded-xl p-8 text-center flex flex-col items-center justify-center min-h-[160px]">
                {isRecording ? (
                  <button
                    type="button"
                    onClick={stopRecording}
                    className="w-16 h-16 rounded-full bg-red-500/20 text-red-500 flex items-center justify-center hover:bg-red-500/30 transition-colors animate-pulse"
                  >
                    <Square className="w-6 h-6 fill-current" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={startRecording}
                    className="w-16 h-16 rounded-full bg-cyan-500/20 text-cyan-500 flex items-center justify-center hover:bg-cyan-500/30 transition-colors"
                  >
                    <Mic className="w-6 h-6" />
                  </button>
                )}
                <span className="text-zinc-400 mt-4">
                  {isRecording ? 'Recording...' : 'Record Audio'}
                </span>
              </div>
            </div>

            {sourceAudio && (
              <div className="mt-4 p-4 bg-zinc-900 rounded-xl border border-zinc-800">
                <audio src={sourceAudio} controls className="w-full" />
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Prompt (Optional)</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="E.g., Transcribe this audio and summarize the key points."
              className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent min-h-[100px] resize-y"
              disabled={isLoading}
            />
          </div>

          <button
            type="submit"
            disabled={!sourceAudio || isLoading || isRecording}
            className="w-full bg-cyan-500 hover:bg-cyan-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-zinc-900 font-medium py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Transcribing...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                Transcribe Audio
              </>
            )}
          </button>
        </form>

        {analysisResult && (
          <div className="bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800 space-y-4">
            <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Transcription Result</h3>
            <div className="prose prose-invert max-w-none">
              <Markdown>{analysisResult}</Markdown>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
