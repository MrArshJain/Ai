import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Play, Code2, MonitorPlay, LayoutTemplate, Coins, Maximize, Minimize } from 'lucide-react';
import { ai } from '../services/gemini';
import Markdown from 'react-markdown';
import Editor from '@monaco-editor/react';

interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
}

const DEFAULT_CODE = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>3D Game Environment</title>
  <style>
    body { margin: 0; overflow: hidden; background: #000; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    canvas { display: block; }
    #ui { position: absolute; top: 20px; left: 20px; color: white; text-shadow: 1px 1px 2px black; pointer-events: none; }
    h1 { margin: 0; font-size: 24px; font-weight: 600; letter-spacing: 1px; }
    p { margin: 5px 0 0 0; font-size: 14px; opacity: 0.8; }
  </style>
  <!-- Load Three.js -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
</head>
<body>
  <div id="ui">
    <h1>3D Engine Ready</h1>
    <p>Awaiting generation...</p>
  </div>
  <script>
    // Basic 3D Scene Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a1a2e);
    scene.fog = new THREE.FogExp2(0x1a1a2e, 0.02);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 5, 10);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    document.body.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(10, 20, 10);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    scene.add(dirLight);

    // Ground
    const groundGeo = new THREE.PlaneGeometry(100, 100);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x16213e, roughness: 0.8, metalness: 0.2 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Floating Object
    const geo = new THREE.IcosahedronGeometry(2, 0);
    const mat = new THREE.MeshStandardMaterial({ 
      color: 0xe94560, 
      roughness: 0.2,
      metalness: 0.8,
      wireframe: true
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.y = 3;
    mesh.castShadow = true;
    scene.add(mesh);

    // Responsive
    window.addEventListener('resize', () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // Animation Loop
    const clock = new THREE.Clock();
    function animate() {
      requestAnimationFrame(animate);
      const time = clock.getElapsedTime();
      
      mesh.rotation.x = time * 0.5;
      mesh.rotation.y = time * 0.3;
      mesh.position.y = 3 + Math.sin(time * 2) * 0.5;
      
      renderer.render(scene, camera);
    }
    animate();
  </script>
</body>
</html>`;

export default function AppBuilder() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [code, setCode] = useState(DEFAULT_CODE);
  const [previewCode, setPreviewCode] = useState(DEFAULT_CODE);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('preview');
  const [credits, setCredits] = useState(300000000000000000000000n);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const extractCode = (text: string) => {
    const match = text.match(/```(?:html)?\n([\s\S]*?)```/);
    return match ? match[1] : null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMessage,
        config: {
          systemInstruction: "You are an elite 3D game developer and software engineer. Generate complete, single-file HTML/JS/CSS code for high-end 3D games and apps. Always wrap your complete code in ```html ... ``` blocks. Use WebGL and Three.js (via CDN like https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js) for 3D rendering. Focus on realistic design for characters, maps, environments, and UI. Include lighting, shadows, and textures where possible. CRITICAL: Ensure the code is fully responsive. Dynamically resize the renderer and camera aspect ratio to window.innerWidth and window.innerHeight and listen for 'resize' events. NEVER hardcode fixed dimensions. Write the best, most optimized code possible.",
        }
      });

      const responseText = response.text || 'No response';
      const extractedCode = extractCode(responseText);
      
      if (extractedCode) {
        setCode(extractedCode);
        setPreviewCode(extractedCode);
        setActiveTab('preview');
      }

      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'model', content: responseText }
      ]);
      
      // Decrement credits slightly just for visual effect, though it's practically infinite
      setCredits(prev => prev - 100n);
    } catch (error) {
      console.error('Error generating content:', error);
      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'model', content: 'Sorry, I encountered an error.' }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const runCode = () => {
    setPreviewCode(code);
    setActiveTab('preview');
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <LayoutTemplate className="w-6 h-6 text-emerald-500" />
            App & Game Builder
          </h2>
          <p className="text-sm text-zinc-400">Powered by gemini-3-flash-preview (Free Tier)</p>
        </div>
        <div className="flex items-center gap-2 bg-emerald-500/10 text-emerald-400 px-4 py-2 rounded-full border border-emerald-500/20">
          <Coins className="w-4 h-4" />
          <div className="flex flex-col">
            <span className="text-xs font-bold leading-none">{credits.toString()}</span>
            <span className="text-[10px] opacity-80 leading-none mt-1">Credits (Refreshes Daily)</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col md:flex-row relative">
        {/* Chat Section */}
        <div className="flex-1 flex flex-col border-r border-zinc-800 md:w-1/3 max-w-md">
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-zinc-500 space-y-4 text-center px-4">
                <LayoutTemplate className="w-16 h-16 opacity-20 text-emerald-500" />
                <p>Describe the app or game you want to build. I will write the code and render it instantly.</p>
              </div>
            )}
            
            {messages.map((msg) => (
              <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  msg.role === 'user' ? 'bg-emerald-500' : 'bg-zinc-800'
                }`}>
                  {msg.role === 'user' ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-emerald-500" />}
                </div>
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  msg.role === 'user' 
                    ? 'bg-emerald-500 text-white' 
                    : 'bg-zinc-800 text-zinc-200'
                }`}>
                  {msg.role === 'user' ? (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  ) : (
                    <div className="markdown-body prose prose-invert max-w-none text-sm">
                      <Markdown>{msg.content}</Markdown>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center shrink-0">
                  <Bot className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="bg-zinc-800 rounded-2xl px-4 py-3 flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin text-zinc-400" />
                  <span className="text-zinc-400">Building...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 bg-zinc-950/50 border-t border-zinc-800">
            <form onSubmit={handleSubmit} className="relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="E.g., Build a snake game..."
                className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-full pl-6 pr-14 py-4 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="absolute right-2 top-2 bottom-2 aspect-square flex items-center justify-center bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white rounded-full transition-colors"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>

        {/* Editor & Preview Section */}
        <div className={`${isFullscreen ? 'fixed inset-0 z-50 flex flex-col' : 'flex-1 flex flex-col md:w-2/3'} bg-[#1e1e1e] transition-all duration-200`}>
          <div className="flex items-center justify-between p-2 border-b border-zinc-800 bg-zinc-900">
            <div className="flex items-center gap-1 bg-zinc-950 rounded-lg p-1">
              <button
                onClick={() => setActiveTab('preview')}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  activeTab === 'preview' ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <MonitorPlay className="w-4 h-4" />
                Live Preview
              </button>
              <button
                onClick={() => setActiveTab('editor')}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  activeTab === 'editor' ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Code2 className="w-4 h-4" />
                Code Editor
              </button>
            </div>
            <div className="flex items-center gap-2">
              {activeTab === 'editor' && (
                <button
                  onClick={runCode}
                  className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-1.5 rounded-md text-sm font-medium transition-colors"
                >
                  <Play className="w-4 h-4" />
                  Update Preview
                </button>
              )}
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="flex items-center justify-center w-8 h-8 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
              >
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </button>
            </div>
          </div>
          
          <div className="flex-1 relative">
            {activeTab === 'editor' ? (
              <Editor
                height="100%"
                defaultLanguage="html"
                theme="vs-dark"
                value={code}
                onChange={(value) => setCode(value || '')}
                options={{
                  minimap: { enabled: false },
                  fontSize: 14,
                  wordWrap: 'on',
                  padding: { top: 16 },
                }}
              />
            ) : (
              <iframe
                title="Live Preview"
                srcDoc={previewCode}
                className="w-full h-full bg-white border-none"
                sandbox="allow-scripts allow-same-origin"
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
