import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Play, Code2, MonitorPlay, Smartphone, Coins, Maximize, Minimize } from 'lucide-react';
import { ai } from '../services/gemini';
import Markdown from 'react-markdown';
import Editor from '@monaco-editor/react';

interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
}

const DEFAULT_CODE = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Android 3D Game</title>
  <style>
    body { margin: 0; overflow: hidden; background: #000; touch-action: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    canvas { display: block; }
    #ui { position: absolute; top: 20px; left: 20px; color: white; pointer-events: none; text-shadow: 1px 1px 3px rgba(0,0,0,0.8); }
    h1 { margin: 0; font-size: 22px; font-weight: 600; }
    p { margin: 5px 0 0 0; font-size: 14px; opacity: 0.9; }
    #score-container { position: absolute; top: 20px; right: 20px; background: rgba(0,0,0,0.5); padding: 10px 20px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.2); color: #ffd700; font-size: 20px; font-weight: bold; }
    #joystick-zone { position: absolute; bottom: 40px; left: 40px; width: 120px; height: 120px; background: rgba(255,255,255,0.1); border-radius: 50%; border: 2px solid rgba(255,255,255,0.3); touch-action: none; z-index: 10; }
    #joystick-knob { position: absolute; top: 50%; left: 50%; width: 50px; height: 50px; background: rgba(255,255,255,0.6); border-radius: 50%; transform: translate(-50%, -50%); pointer-events: none; box-shadow: 0 4px 10px rgba(0,0,0,0.3); }
    #install-btn { margin-top: 10px; padding: 8px 16px; background: #10b981; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; pointer-events: auto; box-shadow: 0 4px 6px rgba(0,0,0,0.3); }
    #pause-btn { position: absolute; top: 20px; right: 140px; width: 40px; height: 40px; background: rgba(0,0,0,0.5); color: white; border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; z-index: 20; display: flex; align-items: center; justify-content: center; }
    #customize-btn { position: absolute; top: 20px; right: 80px; width: 40px; height: 40px; background: rgba(0,0,0,0.5); color: white; border: 1px solid rgba(255,255,255,0.2); border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; z-index: 20; display: flex; align-items: center; justify-content: center; }
    #health-container { position: absolute; top: 70px; right: 20px; width: 160px; height: 20px; background: rgba(0,0,0,0.5); border-radius: 10px; border: 1px solid rgba(255,255,255,0.2); overflow: hidden; }
    #health-bar { width: 100%; height: 100%; background: #ef4444; transition: width 0.2s; }
    #pause-menu { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 100; display: none; flex-direction: column; align-items: center; justify-content: center; color: white; }
    #customize-panel { position: absolute; top: 70px; right: 80px; background: rgba(0,0,0,0.8); padding: 15px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); z-index: 20; display: none; color: white; flex-direction: column; gap: 10px; }
    .color-picker { display: flex; align-items: center; justify-content: space-between; gap: 10px; font-size: 14px; }
    .color-picker input, .color-picker select { cursor: pointer; background: #333; color: white; border: 1px solid #555; border-radius: 4px; padding: 2px; }
    .menu-btn { margin: 10px; padding: 15px 30px; font-size: 18px; background: #3b82f6; color: white; border: none; border-radius: 8px; width: 220px; cursor: pointer; font-weight: bold; }
    .menu-btn:hover { background: #2563eb; }
  </style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
</head>
<body>
  <div id="ui">
    <h1>Android 3D Engine</h1>
    <p>Use the virtual joystick to explore. Tap anywhere to jump!</p>
    <button id="install-btn">Install APK</button>
  </div>
  <div id="score-container">Score: <span id="score">0</span></div>
  <div id="health-container"><div id="health-bar"></div></div>
  <button id="pause-btn">⏸</button>
  <button id="customize-btn">👕</button>
  <div id="pause-menu">
    <h1 style="margin-bottom: 30px; font-size: 32px;">PAUSED</h1>
    <button class="menu-btn" id="resume-btn">Resume</button>
    <button class="menu-btn" id="settings-btn">Sound: ON</button>
    <button class="menu-btn" id="quit-btn" style="background: #ef4444;">Quit (Reset)</button>
  </div>
  <div id="customize-panel">
    <div class="color-picker">
      <label>Shirt Color:</label>
      <input type="color" id="shirt-color" value="#2c3e50">
    </div>
    <div class="color-picker">
      <label>Pants Color:</label>
      <input type="color" id="pants-color" value="#1a252f">
    </div>
    <div class="color-picker">
      <label>Skin Color:</label>
      <input type="color" id="skin-color" value="#f1c27d">
    </div>
    <div class="color-picker">
      <label>Accessory:</label>
      <select id="accessory-select">
        <option value="none">None</option>
        <option value="hat">Hat</option>
        <option value="glasses">Glasses</option>
      </select>
    </div>
  </div>
  <div id="joystick-zone">
    <div id="joystick-knob"></div>
  </div>
  <script>
    // Background Music (Web Audio API)
    let audioCtx;
    let oscillator;
    let gainNode;
    let isMusicPlaying = false;

    function startMusic() {
      if (isMusicPlaying) return;
      
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      oscillator = audioCtx.createOscillator();
      gainNode = audioCtx.createGain();

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(220, audioCtx.currentTime); // Subtle frequency
      gainNode.gain.setValueAtTime(0.05, audioCtx.currentTime); // Subtle volume

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.start();
      
      isMusicPlaying = true;
    }
    
    // Trigger on first user interaction
    document.addEventListener('click', startMusic, { once: true });

    // 3D Scene Setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB); // Sky blue
    scene.fog = new THREE.FogExp2(0x87CEEB, 0.015);

    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 6, 10);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Optimize for mobile
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    document.body.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(20, 40, 20);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 100;
    dirLight.shadow.camera.left = -50;
    dirLight.shadow.camera.right = 50;
    dirLight.shadow.camera.top = 50;
    dirLight.shadow.camera.bottom = -50;
    scene.add(dirLight);

    // Helper to get terrain height at specific x, z (Complex Sine Waves / Pseudo-Perlin)
    function getTerrainHeight(x, z) {
        let y = 0;
        y += Math.sin(x * 0.03 + z * 0.02) * 4.0;
        y += Math.cos(x * 0.07 - z * 0.04) * 2.0;
        y += Math.sin(x * 0.14 + z * 0.11) * 0.5;
        // Plateau effect: flatten out tops
        if (y > 3.0) y = 3.0 + (y - 3.0) * 0.1;
        // Gentle slopes: smooth out the bottom
        if (y < -2.0) y = -2.0 + (y + 2.0) * 0.3;
        return y;
    }

    // Terrain Generation (Rolling Hills & Plateaus)
    const groundGeo = new THREE.PlaneGeometry(200, 200, 100, 100);
    const pos = groundGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i);
        const y = pos.getY(i);
        const z = getTerrainHeight(x, y);
        pos.setZ(i, z);
    }
    groundGeo.computeVertexNormals();
    
    const groundMat = new THREE.MeshStandardMaterial({ 
        color: 0x3b5e2b, 
        roughness: 0.9, 
        metalness: 0.05,
        flatShading: true // Gives a nice low-poly realistic vibe
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Player Character (Humanoid)
    const playerGroup = new THREE.Group();
    
    // Torso
    const torsoGeo = new THREE.BoxGeometry(0.8, 1.2, 0.4);
    const clothMat = new THREE.MeshStandardMaterial({ color: 0x2c3e50, roughness: 0.8 });
    const torso = new THREE.Mesh(torsoGeo, clothMat);
    torso.position.y = 1.2;
    torso.castShadow = true;
    playerGroup.add(torso);

    // Head
    const headGeo = new THREE.SphereGeometry(0.3, 32, 32);
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xf1c27d, roughness: 0.4 });
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.y = 2.0;
    head.castShadow = true;
    playerGroup.add(head);

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.15, 0.15, 0.8, 16);
    const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1a252f, roughness: 0.9 });
    const leftLeg = new THREE.Mesh(legGeo, pantsMat);
    leftLeg.position.set(-0.2, 0.4, 0);
    leftLeg.castShadow = true;
    playerGroup.add(leftLeg);
    
    const rightLeg = new THREE.Mesh(legGeo, pantsMat);
    rightLeg.position.set(0.2, 0.4, 0);
    rightLeg.castShadow = true;
    playerGroup.add(rightLeg);

    scene.add(playerGroup);

    // Flora (Trees and Bushes)
    const floraGroup = new THREE.Group();
    scene.add(floraGroup);
    const animatedFlora = [];

    const pineGeo = new THREE.ConeGeometry(1.5, 4, 8);
    const pineMat = new THREE.MeshStandardMaterial({ color: 0x1e4620, roughness: 0.9, flatShading: true });
    
    const oakGeo = new THREE.DodecahedronGeometry(2);
    const oakMat = new THREE.MeshStandardMaterial({ color: 0x3a5f2b, roughness: 0.8, flatShading: true });
    
    const trunkGeo = new THREE.CylinderGeometry(0.3, 0.4, 1.5, 8);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3018, roughness: 1.0 });
    
    const bushGeo = new THREE.DodecahedronGeometry(0.8);
    const bushMat = new THREE.MeshStandardMaterial({ color: 0x2d4c1e, roughness: 0.9, flatShading: true });

    for(let i=0; i<80; i++) {
        const x = (Math.random() - 0.5) * 180;
        const z = (Math.random() - 0.5) * 180;
        if (Math.abs(x) < 8 && Math.abs(z) < 8) continue; // Keep center clear
        
        const y = getTerrainHeight(x, z);
        const type = Math.random();
        
        if (type < 0.35) { // Pine Tree
            const tree = new THREE.Group();
            const leaves = new THREE.Mesh(pineGeo, pineMat);
            leaves.position.y = 2.5;
            leaves.castShadow = true;
            const trunk = new THREE.Mesh(trunkGeo, trunkMat);
            trunk.position.y = 0.75;
            trunk.castShadow = true;
            tree.add(leaves); tree.add(trunk);
            tree.position.set(x, y, z);
            floraGroup.add(tree);
            animatedFlora.push({ mesh: leaves, speed: Math.random() * 0.5 + 0.5, origX: leaves.rotation.x, origZ: leaves.rotation.z });
        } else if (type < 0.7) { // Oak Tree
            const tree = new THREE.Group();
            const leaves = new THREE.Mesh(oakGeo, oakMat);
            leaves.position.y = 2.5;
            leaves.castShadow = true;
            const trunk = new THREE.Mesh(trunkGeo, trunkMat);
            trunk.position.y = 0.75;
            trunk.castShadow = true;
            tree.add(leaves); tree.add(trunk);
            tree.position.set(x, y, z);
            floraGroup.add(tree);
            animatedFlora.push({ mesh: leaves, speed: Math.random() * 0.5 + 0.5, origX: leaves.rotation.x, origZ: leaves.rotation.z });
        } else { // Bush
            const bush = new THREE.Mesh(bushGeo, bushMat);
            bush.position.set(x, y + 0.4, z);
            bush.castShadow = true;
            floraGroup.add(bush);
            animatedFlora.push({ mesh: bush, speed: Math.random() * 0.8 + 0.2, origX: bush.rotation.x, origZ: bush.rotation.z });
        }
    }

    // Rocks (Additional Assets)
    const rockGeo = new THREE.DodecahedronGeometry(1.2, 1);
    const rockMat = new THREE.MeshStandardMaterial({ color: 0x555555, roughness: 0.9, flatShading: true });
    for(let i=0; i<30; i++) {
        const x = (Math.random() - 0.5) * 180;
        const z = (Math.random() - 0.5) * 180;
        if (Math.abs(x) < 8 && Math.abs(z) < 8) continue;
        const y = getTerrainHeight(x, z);
        const rock = new THREE.Mesh(rockGeo, rockMat);
        rock.position.set(x, y + 0.2, z);
        rock.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
        rock.scale.set(1 + Math.random(), 0.5 + Math.random(), 1 + Math.random());
        rock.castShadow = true;
        floraGroup.add(rock);
    }

    // Weather Effects: Wind Particles (Leaves/Dust)
    const particleCount = 300;
    const particleGeo = new THREE.BufferGeometry();
    const particlePos = new Float32Array(particleCount * 3);
    for(let i=0; i<particleCount * 3; i++) {
        particlePos[i] = (Math.random() - 0.5) * 100;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePos, 3));
    const particleMat = new THREE.PointsMaterial({ 
        color: 0x88aa66, 
        size: 0.3, 
        transparent: true, 
        opacity: 0.6 
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    particles.position.y = 5;
    scene.add(particles);

    // Collectibles (Coins)
    const collectibles = [];
    const coinGeo = new THREE.TorusGeometry(0.3, 0.1, 16, 32);
    const coinMat = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 1.0, roughness: 0.2 });
    
    for(let i=0; i<40; i++) {
        const coin = new THREE.Mesh(coinGeo, coinMat);
        const x = (Math.random() - 0.5) * 100;
        const z = (Math.random() - 0.5) * 100;
        const y = getTerrainHeight(x, z) + 0.8; // Float above terrain
        coin.position.set(x, y, z);
        coin.castShadow = true;
        scene.add(coin);
        collectibles.push(coin);
    }

    // NPCs (Basic AI)
    const npcs = [];
    const npcGeo = new THREE.BoxGeometry(1, 1.5, 1);
    const npcMat = new THREE.MeshStandardMaterial({ color: 0xff4444, roughness: 0.7 });
    const npcHeadGeo = new THREE.BoxGeometry(0.8, 0.8, 0.8);

    for(let i=0; i<5; i++) {
        const npc = new THREE.Group();
        const body = new THREE.Mesh(npcGeo, npcMat);
        body.position.y = 0.75;
        body.castShadow = true;
        
        const head = new THREE.Mesh(npcHeadGeo, npcMat);
        head.position.y = 1.9;
        head.castShadow = true;
        
        npc.add(body);
        npc.add(head);
        
        const startX = (Math.random() - 0.5) * 80;
        const startZ = (Math.random() - 0.5) * 80;
        npc.position.set(startX, getTerrainHeight(startX, startZ), startZ);
        
        scene.add(npc);
        
        npcs.push({
            mesh: npc,
            target: new THREE.Vector3((Math.random() - 0.5) * 80, 0, (Math.random() - 0.5) * 80),
            speed: 2 + Math.random() * 2,
            state: 'patrol'
        });
    }

    // Virtual Joystick Logic
    const zone = document.getElementById('joystick-zone');
    const knob = document.getElementById('joystick-knob');
    let isDragging = false;
    let moveVector = new THREE.Vector3(0, 0, 0);

    zone.addEventListener('touchstart', handleStart, {passive: false});
    zone.addEventListener('touchmove', handleMove, {passive: false});
    zone.addEventListener('touchend', handleEnd);
    zone.addEventListener('mousedown', handleStart);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleEnd);

    function handleStart(e) {
      e.preventDefault();
      initAudio(); // Initialize audio on first interaction
      isDragging = true;
      updateJoystick(e);
    }

    function handleMove(e) {
      if (!isDragging) return;
      e.preventDefault();
      updateJoystick(e);
    }

    function handleEnd() {
      isDragging = false;
      knob.style.transform = \`translate(-50%, -50%)\`;
      moveVector.set(0, 0, 0);
    }

    function updateJoystick(e) {
      const rect = zone.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      let dx = clientX - centerX;
      let dy = clientY - centerY;
      
      const distance = Math.sqrt(dx * dx + dy * dy);
      const maxDistance = rect.width / 2;
      
      if (distance > maxDistance) {
        dx = (dx / distance) * maxDistance;
        dy = (dy / distance) * maxDistance;
      }
      
      knob.style.transform = \`translate(calc(-50% + \${dx}px), calc(-50% + \${dy}px))\`;
      moveVector.set(dx / maxDistance, 0, dy / maxDistance);
    }

    // Responsive
    window.addEventListener('resize', () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // Game State
    let score = 0;
    const scoreEl = document.getElementById('score');
    let health = 100;
    const healthBar = document.getElementById('health-bar');

    // Audio System (Web Audio API)
    let audioCtx;
    let soundEnabled = true;
    function initAudio() {
        if (audioCtx) return;
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        audioCtx = new AudioContext();
        
        // Background Music (Ambient Drone)
        const bgmOsc = audioCtx.createOscillator();
        const bgmGain = audioCtx.createGain();
        bgmOsc.type = 'triangle';
        bgmOsc.frequency.setValueAtTime(110, audioCtx.currentTime); // A2
        bgmGain.gain.value = 0.05;
        bgmOsc.connect(bgmGain);
        bgmGain.connect(audioCtx.destination);
        bgmOsc.start();
    }

    function playCoinSound() {
        if (!audioCtx || !soundEnabled) return;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1760, audioCtx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.1);
    }

    function playJumpSound() {
        if (!audioCtx || !soundEnabled) return;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(150, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(300, audioCtx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.2);
    }

    // Jump State
    let velocityY = 0;
    let isGrounded = true;
    const gravity = -25;
    const jumpStrength = 12;
    let isPaused = false;

    function jump(e) {
        initAudio(); // Initialize audio on first interaction
        if (isPaused) return;
        if (e && e.target) {
            if (e.target.id === 'joystick-zone' || e.target.id === 'joystick-knob' || e.target.tagName === 'BUTTON' || e.target.closest('#pause-menu') || e.target.closest('#customize-panel')) return;
        }
        if (isGrounded) {
            velocityY = jumpStrength;
            isGrounded = false;
            playJumpSound();
        }
    }
    window.addEventListener('touchstart', jump, {passive: false});
    window.addEventListener('mousedown', jump);

    // Install APK Logic
    document.getElementById('install-btn').addEventListener('click', () => {
        alert('To install as a native Android APK, you can wrap this HTML file using tools like WebIntoApp, Cordova, or PWA Builder. Downloading game source now...');
        const blob = new Blob([document.documentElement.outerHTML], {type: 'text/html'});
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'Android3DGame.html';
        a.click();
    });

    // Pause Menu Logic
    const pauseBtn = document.getElementById('pause-btn');
    const pauseMenu = document.getElementById('pause-menu');
    const resumeBtn = document.getElementById('resume-btn');
    const settingsBtn = document.getElementById('settings-btn');
    const quitBtn = document.getElementById('quit-btn');

    pauseBtn.addEventListener('click', () => {
        isPaused = true;
        pauseMenu.style.display = 'flex';
    });

    resumeBtn.addEventListener('click', () => {
        isPaused = false;
        pauseMenu.style.display = 'none';
    });

    settingsBtn.addEventListener('click', () => {
        soundEnabled = !soundEnabled;
        settingsBtn.innerText = \`Sound: \${soundEnabled ? 'ON' : 'OFF'}\`;
        if (audioCtx) {
            if (soundEnabled) audioCtx.resume();
            else audioCtx.suspend();
        }
    });

    quitBtn.addEventListener('click', () => {
        // Reset game state
        playerGroup.position.set(0, 10, 0);
        score = 0;
        scoreEl.innerText = score;
        health = 100;
        healthBar.style.width = '100%';
        isPaused = false;
        pauseMenu.style.display = 'none';
    });

    // Customization Logic
    const customizeBtn = document.getElementById('customize-btn');
    const customizePanel = document.getElementById('customize-panel');
    const shirtColorInput = document.getElementById('shirt-color');
    const pantsColorInput = document.getElementById('pants-color');
    const skinColorInput = document.getElementById('skin-color');
    const accessorySelect = document.getElementById('accessory-select');

    let accessoryMesh = null;

    customizeBtn.addEventListener('click', () => {
        customizePanel.style.display = customizePanel.style.display === 'flex' ? 'none' : 'flex';
    });

    shirtColorInput.addEventListener('input', (e) => {
        clothMat.color.set(e.target.value);
    });

    pantsColorInput.addEventListener('input', (e) => {
        pantsMat.color.set(e.target.value);
    });

    skinColorInput.addEventListener('input', (e) => {
        skinMat.color.set(e.target.value);
    });

    accessorySelect.addEventListener('change', (e) => {
        if (accessoryMesh) {
            head.remove(accessoryMesh);
            accessoryMesh = null;
        }
        if (e.target.value === 'hat') {
            const hatGeo = new THREE.CylinderGeometry(0.2, 0.4, 0.3, 16);
            const hatMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
            accessoryMesh = new THREE.Mesh(hatGeo, hatMat);
            accessoryMesh.position.y = 0.3;
            head.add(accessoryMesh);
        } else if (e.target.value === 'glasses') {
            const glassesGeo = new THREE.BoxGeometry(0.5, 0.1, 0.1);
            const glassesMat = new THREE.MeshStandardMaterial({ color: 0x111111 });
            accessoryMesh = new THREE.Mesh(glassesGeo, glassesMat);
            accessoryMesh.position.set(0, 0.1, 0.25);
            head.add(accessoryMesh);
        }
    });

    // Animation Loop
    const clock = new THREE.Clock();
    function animate() {
      requestAnimationFrame(animate);
      const delta = clock.getDelta();
      
      if (isPaused) return; // Skip updates if paused
      
      const time = clock.getElapsedTime();
      
      // Move player
      if (moveVector.lengthSq() > 0) {
        const speed = 8;
        playerGroup.position.x += moveVector.x * speed * delta;
        playerGroup.position.z += moveVector.z * speed * delta;
        
        // Smoothly rotate player to face movement direction
        const targetAngle = Math.atan2(moveVector.x, moveVector.z);
        let diff = targetAngle - playerGroup.rotation.y;
        while (diff < -Math.PI) diff += Math.PI * 2;
        while (diff > Math.PI) diff -= Math.PI * 2;
        playerGroup.rotation.y += diff * 10 * delta;
      }
      
      // Adjust player height to terrain + jumping + bobbing
      let currentTerrainY = -50; // Fall threshold if out of bounds
      const isOutOfBounds = playerGroup.position.x < -100 || playerGroup.position.x > 100 || 
                            playerGroup.position.z < -100 || playerGroup.position.z > 100;
      
      if (!isOutOfBounds) {
          currentTerrainY = getTerrainHeight(playerGroup.position.x, playerGroup.position.z);
      }
      
      if (!isGrounded || isOutOfBounds) {
          velocityY += gravity * delta;
          playerGroup.position.y += velocityY * delta;
          if (!isOutOfBounds && playerGroup.position.y <= currentTerrainY) {
              playerGroup.position.y = currentTerrainY;
              isGrounded = true;
              velocityY = 0;
          }
      } else {
          const bobbing = moveVector.lengthSq() > 0 ? Math.abs(Math.sin(time * 10)) * 0.2 : 0;
          playerGroup.position.y = currentTerrainY + bobbing;
      }

      // Respawn Mechanism
      if (playerGroup.position.y < -20) {
          playerGroup.position.set(0, 10, 0);
          velocityY = 0;
          isGrounded = false;
          score = Math.max(0, score - 5); // Penalty for falling
          scoreEl.innerText = score;
          health = Math.max(0, health - 20); // Fall damage
          healthBar.style.width = health + '%';
          if (health <= 0) {
              health = 100;
              healthBar.style.width = '100%';
              score = Math.max(0, score - 20);
              scoreEl.innerText = score;
          }
          playJumpSound(); // Audio feedback for respawn
      }
      
      // Animate Flora (Wind effect)
      animatedFlora.forEach(item => {
          item.mesh.rotation.x = item.origX + Math.sin(time * item.speed) * 0.05;
          item.mesh.rotation.z = item.origZ + Math.cos(time * item.speed) * 0.05;
      });

      // Animate Weather Particles (Wind blowing leaves/dust)
      const positions = particles.geometry.attributes.position.array;
      for(let i=0; i<particleCount; i++) {
          positions[i*3] += 0.05; // Wind X
          positions[i*3+1] -= 0.02; // Gravity Y
          positions[i*3+2] += 0.02; // Wind Z
          
          if(positions[i*3] > 50) positions[i*3] = -50;
          if(positions[i*3+1] < -5) positions[i*3+1] = 15;
          if(positions[i*3+2] > 50) positions[i*3+2] = -50;
      }
      particles.geometry.attributes.position.needsUpdate = true;
      
      // Collectibles Logic
      for(let i = collectibles.length - 1; i >= 0; i--) {
          const coin = collectibles[i];
          coin.rotation.y += 2 * delta; // Spin coin
          
          // Floating animation
          coin.position.y = getTerrainHeight(coin.position.x, coin.position.z) + 0.8 + Math.sin(time * 3 + i) * 0.2;
          
          // Collision detection (distance check)
          if (playerGroup.position.distanceTo(coin.position) < 1.5) {
              scene.remove(coin);
              collectibles.splice(i, 1);
              score += 10;
              scoreEl.innerText = score;
              playCoinSound();
              
              // Simple scale pop effect on player
              playerGroup.scale.set(1.2, 1.2, 1.2);
              setTimeout(() => playerGroup.scale.set(1, 1, 1), 100);
          }
      }
      
      // Update NPCs (AI Logic)
      npcs.forEach(npc => {
          const m = npc.mesh;
          const t = npc.target;
          
          // Detection and Chasing Logic
          const distToPlayer = m.position.distanceTo(playerGroup.position);
          const detectionRange = 15.0;
          
          if (distToPlayer < detectionRange) {
              npc.state = 'chase';
              t.copy(playerGroup.position); // Update target to player's current position
              npc.speed = 5.0; // Run faster when chasing
          } else if (npc.state === 'chase') {
              npc.state = 'patrol';
              npc.speed = 2 + Math.random() * 2; // Back to normal speed
              t.set((Math.random() - 0.5) * 80, 0, (Math.random() - 0.5) * 80); // Pick new patrol point
          }

          const dx = t.x - m.position.x;
          const dz = t.z - m.position.z;
          const dist = Math.sqrt(dx*dx + dz*dz);
          
          if (dist < 1.0 && npc.state === 'patrol') {
              // Pick new waypoint
              t.set((Math.random() - 0.5) * 80, 0, (Math.random() - 0.5) * 80);
          } else if (dist >= 1.0 || npc.state === 'chase') {
              // Move towards waypoint
              const vx = (dx / dist) * npc.speed * delta;
              const vz = (dz / dist) * npc.speed * delta;
              m.position.x += vx;
              m.position.z += vz;
              
              // Adjust height to terrain (faster bobbing when chasing)
              m.position.y = getTerrainHeight(m.position.x, m.position.z) + Math.abs(Math.sin(time * (npc.state === 'chase' ? 15 : 8))) * 0.1;
              
              // Rotate to face target
              const targetAngle = Math.atan2(vx, vz);
              let diff = targetAngle - m.rotation.y;
              while (diff < -Math.PI) diff += Math.PI * 2;
              while (diff > Math.PI) diff -= Math.PI * 2;
              m.rotation.y += diff * 5 * delta;
          }
          
          // Catch Player Logic
          if (distToPlayer < 1.5 && npc.state === 'chase') {
              // Push player away slightly
              const pushX = (playerGroup.position.x - m.position.x) * 10 * delta;
              const pushZ = (playerGroup.position.z - m.position.z) * 10 * delta;
              playerGroup.position.x += pushX;
              playerGroup.position.z += pushZ;
              
              // Deduct health
              if (Math.random() < 0.2) { // Throttle health deduction
                  health = Math.max(0, health - 5);
                  healthBar.style.width = health + '%';
                  if (health <= 0) {
                      // Die and respawn
                      playerGroup.position.set(0, 10, 0);
                      health = 100;
                      healthBar.style.width = '100%';
                      score = Math.max(0, score - 20);
                      scoreEl.innerText = score;
                      playJumpSound();
                  }
              }
          }
      });
      
      // Smooth camera follow
      const targetCamPos = playerGroup.position.clone().add(new THREE.Vector3(0, 6, 12));
      camera.position.lerp(targetCamPos, 0.1);
      camera.lookAt(playerGroup.position);
      
      renderer.render(scene, camera);
    }
    animate();
  </script>
</body>
</html>`;


export default function Android3DBuilder() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [code, setCode] = useState(DEFAULT_CODE);
  const [previewCode, setPreviewCode] = useState(DEFAULT_CODE);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('preview');
  const [credits, setCredits] = useState(300000000000000000000000n);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [logs, setLogs] = useState<{level: string, args: string[]}[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'console') {
        setLogs(prev => [...prev, { level: event.data.level, args: event.data.args }]);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  useEffect(() => {
    document.body.style.overflow = 'auto';
  }, [activeTab]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const extractCode = (text: string) => {
    const match = text.match(/```(?:\w+)?\s*([\s\S]*?)```/);
    return match ? match[1].trim() : null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMessage,
        config: {
          systemInstruction: "You are an elite game developer. Your goal is to create COMPLETE, PLAYABLE, and ROBUST games. \n\n1. LANGUAGE CHOICE: Choose the best language for the game (e.g., Python/Pygame, HTML/JS/Three.js, C#/Unity). Prioritize Python/Pygame for desktop/general logic, and HTML/JS/Three.js for mobile/web.\n\n2. CORE PLAYABILITY FIRST: Focus on the core game loop, mechanics, and controls. A simple, polished game is better than a complex, broken one. Ensure collisions, player movement, and win/loss states work flawlessly.\n\n3. CODE QUALITY & STRUCTURE: Write clean, modular, and well-commented code. Even in single-file solutions, use clear functions and classes. Proactively analyze your code for logic flaws, performance bottlenecks, and syntax issues before finalizing.\n\n4. IMMERSION: Include sound effects, background music, and visual effects (particles, shaders). Audio must start on the first user interaction.\n\n5. UI & UX: Create responsive, intuitive UI (menus, HUD, settings). Ensure controls are touch-friendly for mobile.\n\n6. SELF-VERIFICATION: Before outputting, verify: Is the game playable? Are core mechanics robust? Is the code bug-free? Is the UI/UX polished? If not, fix it.\n\n7. OUTPUT: Wrap code in appropriate markdown blocks (e.g., ```python ... ```, ```html ... ```).",
        },
      });

      const responseText = response.text || 'No response';
      const extractedCode = extractCode(responseText);
      
      if (extractedCode) {
        setCode(extractedCode);
        setPreviewCode(extractedCode);
        setActiveTab('preview');
      } else {
        setMessages(prev => [
          ...prev,
          { id: (Date.now() + 2).toString(), role: 'model', content: 'I could not extract any code from the response. Please try asking again.' }
        ]);
      }

      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'model', content: responseText }
      ]);
      
      setCredits(prev => prev - 100n);
    } catch (error) {
      console.error('Error generating content:', error);
      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'model', content: 'Sorry, I encountered an error.' }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const runCode = () => {
    setPreviewCode(code);
    setActiveTab('preview');
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <Smartphone className="w-6 h-6 text-emerald-500" />
            Android 3D Game Builder
          </h2>
          <p className="text-sm text-zinc-400">Powered by gemini-3-flash-preview (Free Tier)</p>
        </div>
        <div className="flex items-center gap-2 bg-emerald-500/10 text-emerald-400 px-4 py-2 rounded-full border border-emerald-500/20">
          <Coins className="w-4 h-4" />
          <div className="flex flex-col">
            <span className="text-xs font-bold leading-none">{credits.toString()}</span>
            <span className="text-[10px] opacity-80 leading-none mt-1">Credits (Refreshes Daily)</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col md:flex-row relative">
        {/* Chat Section */}
        <div className="flex flex-col border-r border-zinc-800 w-full md:w-80 lg:w-96 shrink-0 min-h-0">
          <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-zinc-700 scrollbar-track-transparent">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-zinc-500 space-y-4 text-center px-4">
                <Smartphone className="w-16 h-16 opacity-20 text-emerald-500" />
                <p>Describe the Android 3D game you want to build. I will write the code with realistic 3D characters and touch controls.</p>
              </div>
            )}
            
            {messages.map((msg) => (
              <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  msg.role === 'user' ? 'bg-emerald-500' : 'bg-zinc-800'
                }`}>
                  {msg.role === 'user' ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-emerald-500" />}
                </div>
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  msg.role === 'user' 
                    ? 'bg-emerald-500 text-white' 
                    : 'bg-zinc-800 text-zinc-200'
                }`}>
                  {msg.role === 'user' ? (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  ) : (
                    <div className="markdown-body prose prose-invert max-w-none text-sm">
                      <Markdown>{msg.content}</Markdown>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center shrink-0">
                  <Bot className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="bg-zinc-800 rounded-2xl px-4 py-3 flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin text-zinc-400" />
                  <span className="text-zinc-400">Building...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 bg-zinc-950/50 border-t border-zinc-800">
            <form onSubmit={handleSubmit} className="relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="E.g., Build a 3D racing game for Android..."
                className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-full pl-6 pr-14 py-4 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="absolute right-2 top-2 bottom-2 aspect-square flex items-center justify-center bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white rounded-full transition-colors"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>

        {/* Editor & Preview Section */}
        <div className={`${isFullscreen ? 'fixed inset-0 z-50 flex flex-col' : 'flex-1 flex flex-col md:w-2/3'} bg-[#1e1e1e] transition-all duration-200 min-h-0`}>
          <div className="flex items-center justify-between p-2 border-b border-zinc-800 bg-zinc-900">
            <div className="flex items-center gap-1 bg-zinc-950 rounded-lg p-1">
              <button
                onClick={() => setActiveTab('preview')}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  activeTab === 'preview' ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <MonitorPlay className="w-4 h-4" />
                Live Preview
              </button>
              <button
                onClick={() => setActiveTab('editor')}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  activeTab === 'editor' ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Code2 className="w-4 h-4" />
                Code Editor
              </button>
            </div>
            <div className="flex items-center gap-2">
              {activeTab === 'editor' && (
                <button
                  onClick={runCode}
                  className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-1.5 rounded-md text-sm font-medium transition-colors"
                >
                  <Play className="w-4 h-4" />
                  Update Preview
                </button>
              )}
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="flex items-center justify-center w-8 h-8 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
              >
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </button>
            </div>
          </div>
          
          <div className="flex-1 relative">
            {activeTab === 'editor' ? (
              <Editor
                height="100%"
                defaultLanguage="html"
                theme="vs-dark"
                value={code}
                onChange={(value) => setCode(value || '')}
                options={{
                  minimap: { enabled: false },
                  fontSize: 14,
                  wordWrap: 'on',
                  padding: { top: 16 },
                }}
              />
            ) : previewCode.trim().toLowerCase().startsWith('<') ? (
              <div className="flex flex-col h-full">
                <iframe
                  title="Live Preview"
                  srcDoc={`
                    <script>
                      (function() {
                        const originalLog = console.log;
                        const originalError = console.error;
                        console.log = (...args) => {
                          window.parent.postMessage({ type: 'console', level: 'log', args: args.map(a => String(a)) }, '*');
                          originalLog(...args);
                        };
                        console.error = (...args) => {
                          window.parent.postMessage({ type: 'console', level: 'error', args: args.map(a => String(a)) }, '*');
                          originalError(...args);
                        };
                        window.onerror = (msg, url, line, col, error) => {
                          window.parent.postMessage({ type: 'console', level: 'error', args: [String(msg)] }, '*');
                        };
                      })();
                    </script>
                    ${previewCode}
                  `}
                  className="w-full h-2/3 bg-white border-none"
                  sandbox="allow-scripts allow-same-origin"
                />
                <div className="h-1/3 bg-zinc-950 text-zinc-300 p-2 overflow-y-auto font-mono text-xs border-t border-zinc-800">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-bold text-zinc-500">Console</span>
                    <button onClick={() => setLogs([])} className="text-zinc-500 hover:text-white">Clear</button>
                  </div>
                  {logs.map((log, i) => (
                    <div key={i} className={log.level === 'error' ? 'text-red-400' : 'text-zinc-300'}>
                      {log.args.join(' ')}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-4 text-zinc-400">Preview not available for this language. Please download the code.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
