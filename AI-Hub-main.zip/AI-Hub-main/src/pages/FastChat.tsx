import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Zap } from 'lucide-react';
import { ai } from '../services/gemini';
import Markdown from 'react-markdown';

interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
}

export default function FastChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-preview',
        contents: userMessage,
      });

      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'model', content: response.text || 'No response' }
      ]);
    } catch (error) {
      console.error('Error generating content:', error);
      setMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), role: 'model', content: 'Sorry, I encountered an error.' }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50">
        <h2 className="text-xl font-semibold text-white flex items-center gap-2">
          <Zap className="w-6 h-6 text-yellow-500" />
          Fast Chat
        </h2>
        <p className="text-sm text-zinc-400">Powered by gemini-3.1-flash-lite-preview</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-zinc-500 space-y-4">
            <Zap className="w-16 h-16 opacity-20 text-yellow-500" />
            <p>Get lightning fast responses</p>
          </div>
        )}
        
        {messages.map((msg) => (
          <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
              msg.role === 'user' ? 'bg-yellow-500' : 'bg-zinc-800'
            }`}>
              {msg.role === 'user' ? <User className="w-5 h-5 text-zinc-900" /> : <Bot className="w-5 h-5 text-yellow-500" />}
            </div>
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
              msg.role === 'user' 
                ? 'bg-yellow-500 text-zinc-900' 
                : 'bg-zinc-800 text-zinc-200'
            }`}>
              {msg.role === 'user' ? (
                <p className="whitespace-pre-wrap">{msg.content}</p>
              ) : (
                <div className="markdown-body prose prose-invert max-w-none">
                  <Markdown>{msg.content}</Markdown>
                </div>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center shrink-0">
              <Bot className="w-5 h-5 text-yellow-500" />
            </div>
            <div className="bg-zinc-800 rounded-2xl px-4 py-3 flex items-center gap-2">
              <Loader2 className="w-5 h-5 animate-spin text-zinc-400" />
              <span className="text-zinc-400">Thinking fast...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-zinc-950/50 border-t border-zinc-800">
        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask anything quickly..."
            className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-full pl-6 pr-14 py-4 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="absolute right-2 top-2 bottom-2 aspect-square flex items-center justify-center bg-yellow-500 hover:bg-yellow-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-zinc-900 rounded-full transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}
