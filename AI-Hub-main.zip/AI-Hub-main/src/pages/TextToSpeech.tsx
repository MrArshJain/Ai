import { useState } from 'react';
import { Volume2, Loader2, Play } from 'lucide-react';
import { ai } from '../services/gemini';
import { Modality } from '@google/genai';

export default function TextToSpeech() {
  const [prompt, setPrompt] = useState('Hello! I am Gemini, an AI assistant from Google.');
  const [voice, setVoice] = useState('Kore');
  const [isLoading, setIsLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isLoading) return;

    setIsLoading(true);
    setAudioUrl(null);

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-tts',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voice },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        // The audio is returned as 24kHz PCM by default or WAV depending on the exact implementation.
        // Usually it's returned as audio/wav or audio/mp3 if we don't specify, but let's assume it's playable.
        // Actually, the docs say "decode and play audio with sample rate 24000".
        // Let's try to create a standard data URL. If it's raw PCM, it might need Web Audio API.
        // But often inlineData includes the mimeType.
        const mimeType = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.mimeType || 'audio/wav';
        setAudioUrl(`data:${mimeType};base64,${base64Audio}`);
      } else {
        throw new Error('No audio data returned');
      }
    } catch (error) {
      console.error('Error generating speech:', error);
      alert('Failed to generate speech. Please check console for details.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-900 overflow-y-auto">
      <div className="p-4 border-b border-zinc-800 bg-zinc-950/50">
        <h2 className="text-xl font-semibold text-white flex items-center gap-2">
          <Volume2 className="w-6 h-6 text-green-500" />
          Text to Speech
        </h2>
        <p className="text-sm text-zinc-400">Powered by gemini-2.5-flash-preview-tts</p>
      </div>

      <div className="p-6 max-w-4xl mx-auto w-full space-y-8">
        <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800">
          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Text to Speak</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Enter text to convert to speech..."
              className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent min-h-[150px] resize-y"
              disabled={isLoading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-2">Voice</label>
            <select
              value={voice}
              onChange={(e) => setVoice(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 text-white rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-green-500"
              disabled={isLoading}
            >
              <option value="Puck">Puck</option>
              <option value="Charon">Charon</option>
              <option value="Kore">Kore</option>
              <option value="Fenrir">Fenrir</option>
              <option value="Zephyr">Zephyr</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={!prompt.trim() || isLoading}
            className="w-full bg-green-500 hover:bg-green-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-medium py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Play className="w-5 h-5" />
                Generate Speech
              </>
            )}
          </button>
        </form>

        {audioUrl && (
          <div className="bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800 space-y-4">
            <h3 className="text-lg font-medium text-white border-b border-zinc-800 pb-2">Generated Audio</h3>
            <div className="p-4 bg-zinc-900 rounded-xl border border-zinc-800">
              <audio src={audioUrl} controls autoPlay className="w-full" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
