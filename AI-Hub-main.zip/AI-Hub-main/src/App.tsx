/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageSquare, Sparkles, Image as ImageIcon, Video, 
  Mic, Camera, Zap, FileVideo, Brain, Volume2, Menu, X, LayoutTemplate, Smartphone
} from 'lucide-react';
import { useState } from 'react';

// Pages
import Chatbot from './pages/Chatbot';
import ImageGen from './pages/ImageGen';
import VideoGen from './pages/VideoGen';
import VoiceApp from './pages/VoiceApp';
import ImageEdit from './pages/ImageEdit';
import ImageAnalyze from './pages/ImageAnalyze';
import FastChat from './pages/FastChat';
import VideoAnalyze from './pages/VideoAnalyze';
import AudioTranscribe from './pages/AudioTranscribe';
import DeepThink from './pages/DeepThink';
import TextToSpeech from './pages/TextToSpeech';
import AppBuilder from './pages/AppBuilder';
import Android3DBuilder from './pages/Android3DBuilder';

const NAV_ITEMS = [
  { path: '/', label: 'Chatbot', icon: MessageSquare },
  { path: '/fast', label: 'Fast Chat', icon: Zap },
  { path: '/think', label: 'Deep Think', icon: Brain },
  { path: '/builder', label: 'App Builder', icon: LayoutTemplate },
  { path: '/android-3d', label: 'Android 3D', icon: Smartphone },
  { path: '/image-gen', label: 'Image Gen', icon: ImageIcon },
  { path: '/image-edit', label: 'Image Edit', icon: Sparkles },
  { path: '/image-analyze', label: 'Analyze Image', icon: Camera },
  { path: '/video-gen', label: 'Video Gen', icon: Video },
  { path: '/video-analyze', label: 'Analyze Video', icon: FileVideo },
  { path: '/voice', label: 'Voice App', icon: Mic },
  { path: '/transcribe', label: 'Transcribe', icon: Mic },
  { path: '/tts', label: 'Text to Speech', icon: Volume2 },
];

function Sidebar({ isOpen, setIsOpen }: { isOpen: boolean, setIsOpen: (v: boolean) => void }) {
  const location = useLocation();

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-zinc-950 border-r border-zinc-800 transform transition-transform duration-200 ease-in-out
        md:relative md:translate-x-0
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex items-center justify-between p-4 border-b border-zinc-800">
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            AI Hub
          </h1>
          <button onClick={() => setIsOpen(false)} className="md:hidden text-zinc-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <nav className="p-4 space-y-1 overflow-y-auto h-[calc(100vh-73px)]">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={`
                  flex items-center gap-3 px-3 py-2 rounded-lg transition-colors
                  ${isActive 
                    ? 'bg-indigo-500/10 text-indigo-400' 
                    : 'text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200'
                  }
                `}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </>
  );
}

function Layout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="flex h-screen bg-zinc-900 text-zinc-100 overflow-hidden font-sans">
      <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-zinc-800 bg-zinc-950/50 flex items-center px-4 md:hidden">
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="text-zinc-400 hover:text-white p-2 -ml-2 rounded-lg hover:bg-zinc-800"
          >
            <Menu className="w-6 h-6" />
          </button>
          <span className="ml-2 font-semibold text-white">AI Hub</span>
        </header>

        <main className="flex-1 overflow-y-auto relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              <Routes location={location}>
                <Route path="/" element={<Chatbot />} />
                <Route path="/fast" element={<FastChat />} />
                <Route path="/think" element={<DeepThink />} />
                <Route path="/builder" element={<AppBuilder />} />
                <Route path="/android-3d" element={<Android3DBuilder />} />
                <Route path="/image-gen" element={<ImageGen />} />
                <Route path="/image-edit" element={<ImageEdit />} />
                <Route path="/image-analyze" element={<ImageAnalyze />} />
                <Route path="/video-gen" element={<VideoGen />} />
                <Route path="/video-analyze" element={<VideoAnalyze />} />
                <Route path="/voice" element={<VoiceApp />} />
                <Route path="/transcribe" element={<AudioTranscribe />} />
                <Route path="/tts" element={<TextToSpeech />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Layout />
    </Router>
  );
}
